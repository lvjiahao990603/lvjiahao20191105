package com.bawie.a1106.frag;

import android.view.View;

import com.bawie.a1106.R;
import com.bawie.a1106.base.BaseFragment;

/**
 * author: 吕佳豪
 * data: 2019/11/6 09:9:41
 * function:
 */
public class Fragment05 extends BaseFragment {
    @Override
    protected void initData() {

    }

    @Override
    protected void initView(View view) {

    }

    @Override
    protected int getlayout() {
        return R.layout.fragment05;
    }
}
