package com.bawie.a1106.app;

/**
 * author: 吕佳豪
 * data: 2019/11/6 08:8:47
 * function:
 */
public interface Api {
    int TIME=20;
    String STUDENT_URL="http://172.17.8.100/small/";
}
